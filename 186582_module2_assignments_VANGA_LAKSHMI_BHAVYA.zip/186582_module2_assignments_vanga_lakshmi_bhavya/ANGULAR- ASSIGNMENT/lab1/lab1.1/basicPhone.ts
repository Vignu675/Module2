import{Mobile} from './mobile';


export class Basicphone extends Mobile{
  mobiletype:string;
  constructor(mobilebp)
  {
    super(2,"Samsung",2000);
    this.mobiletype=mobilebp;

  }
  printMobileDetails()
  {
      super.printMobileDetails();
      console.log("Mobile Type :"+this.mobiletype);
  }
}