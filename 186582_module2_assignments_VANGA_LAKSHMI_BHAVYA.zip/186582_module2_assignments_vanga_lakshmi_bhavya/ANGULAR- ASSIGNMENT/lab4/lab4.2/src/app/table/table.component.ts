import { Component, OnInit } from '@angular/core';
import data from '../../data/booklist.json'
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  booklist=data

  search: any
  constructor() { }

  ngOnInit() {
  }
  setTypeId(value)
  {
    this.search={id: value}
  }
  setTypeTitle(value)
  {
    this.search={title: value} 
  }
  setTypeAuthor(value)
  {
    this.search={author: value} 
  }
  setTypeYear(value)
  {
    this.search={year: value} 
  }
}
