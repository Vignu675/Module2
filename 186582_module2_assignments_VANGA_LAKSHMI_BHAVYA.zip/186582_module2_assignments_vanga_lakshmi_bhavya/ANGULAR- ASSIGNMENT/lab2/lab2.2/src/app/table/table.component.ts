import { Component, OnInit } from '@angular/core';
import data from '../../data/mydata.json';
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  mydata=data
  constructor() { }
  
  ngOnInit() {
  }
  sortId()
  {
    this.mydata.sort((a,b)=>(a.empId>b.empId) ? 1 : -1)
  }
  sortName()
  {
    this.mydata.sort((a,b)=>(a.empName>b.empName) ? 1 : -1)
  }
  sortSal()
  { 
    this.mydata.sort((a,b)=>(a.empSal>b.empSal) ? 1 : -1)
  }
  sortDep()
  {
    this.mydata.sort((a,b)=>(a.empDep>b.empDep) ? 1 : -1)
  }
}
