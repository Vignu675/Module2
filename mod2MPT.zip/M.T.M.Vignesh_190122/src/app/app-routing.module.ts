import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlayComponent } from './play/play.component';
import { ErrorComponent } from './error/error.component';
import { SuccessComponent } from './success/success.component';

const routes: Routes = [
{path: 'play', component: PlayComponent},
{path: 'success/:id', component: SuccessComponent},
{path: '', component: ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
