import { Component, OnInit } from '@angular/core';

import { GameService } from '../game.service';
import { GameDetails } from '../gamedetails';
import { Route } from '../../../node_modules/@angular/compiler/src/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  games: GameDetails[];
  cardBalance: number = 600;
  constructor(private gameService: GameService, private router: Router) { }

  ngOnInit() {
    this.games = this.gameService.getGames();
  }

}
