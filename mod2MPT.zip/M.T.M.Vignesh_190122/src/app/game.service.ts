import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { GameDetails } from './gamedetails';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  game:GameDetails[];
  cardBalance: number = 600;

  constructor(private http: HttpClient) {
      this.populateGames().subscribe( data => this.game = data, error => console.log(error) );
   }

  populateGames(): Observable<GameDetails[]> {
    return this.http.get<GameDetails[]>('/assets/data/game.json');
  }

  getGames(): GameDetails[] {
    return this.game;
  }

  getCardBalance(rate: number): number {
      this.cardBalance = this.cardBalance-rate;
      return this.cardBalance;
  }
}
