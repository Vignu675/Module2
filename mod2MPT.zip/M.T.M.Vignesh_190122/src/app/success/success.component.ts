import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';

import { GameDetails } from '../gamedetails';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { Route } from '../../../node_modules/@angular/compiler/src/core';


@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  game: GameDetails;

  currBalance: number;

  constructor(private gameService: GameService, private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let gameId: number = this.activatedRoute.snapshot.params["id"];
    this.game = this.gameService.getGames().find(game => game.gameId == gameId);

    this.currBalance = this.gameService.getCardBalance(this.game.gamePrice);
  }


  navigate(path: string) {
    this.router.navigate(['/play']);
  }

}
